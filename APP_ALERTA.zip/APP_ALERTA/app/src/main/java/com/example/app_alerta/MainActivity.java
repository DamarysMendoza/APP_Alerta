package com.example.app_alerta;
import android.view.View;
import android.content.Intent;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.widget.Button;

import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    private TextInputLayout User, Password;
    private Button Ingresar, Registrar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        User = (TextInputLayout) findViewById(R.id.login_User_campo);
        Password = (TextInputLayout) findViewById(R.id.login_Password_campo2);
        Ingresar = (Button) findViewById(R.id.login_ingresar);
        Registrar = (Button) findViewById(R.id.idRegistro);

        Ingresar.setOnClickListener(new View.OnClickListener() { //solo por mientras se va a esa pantalla porque aun no esta la principal
            @Override
            public void onClick(View v) {
                Intent olvido = new Intent(getApplicationContext(), Olvido_contrase.class);
                startActivity(olvido);
            }
        });
        Registrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Registro = new Intent(getApplicationContext(), Registro_Usuario.class);
                startActivity(Registro);
            }
        });



//        Ingresar.setOnClickListener((View.OnClickListener) this);

    }








    private boolean ValidarUser(String Usuario){
        Pattern patron = Pattern.compile("^[a-zA-Z0-9]+$");
        if(Usuario.length() < 1) {
            User.setError("UsuarioClass Vacio");
            return false;
        }
        if (!patron.matcher(Usuario).matches() || Usuario.length() > 20) {
            User.setError("UsuarioClass Invalido");
            return false;
        } else {
            User.setError(null);
        }
        return true;
    }

    private boolean ValidarPassWord(String PassWord){
        if (PassWord.length() < 1) {
            Password.setError("Contraseña Vacia");
            return false;
        } else{
            Password.setError(null);
        }
        return true;
    }

}
